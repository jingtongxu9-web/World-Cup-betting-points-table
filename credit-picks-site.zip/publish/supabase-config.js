window.CREDIT_APP_SUPABASE = {
  url: "https://ltgvxacfkhxffgfpdhoa.supabase.co",
  anonKey: "sb_publishable_j0akwIXHFTZKJuwhZi2Gcg_o3Gwgorg",
  table: "credit_app_state",
  rowId: "main",
};
