const STORAGE_KEY = "credit-picks-v1";
const COMBINED_LANE_ID = "winner_score";
const DEFAULT_STATE = {
  players: [],
  matches: [],
  predictions: [],
  ledger: [],
};

const state = loadState();
const cloud = {
  client: null,
  config: getSupabaseConfig(),
  ready: false,
  saveTimer: null,
  syncing: false,
};

const dom = {
  cloudStatus: document.querySelector("#cloudStatus"),
  exportDataButton: document.querySelector("#exportDataButton"),
  importDataInput: document.querySelector("#importDataInput"),
  leaderboard: document.querySelector("#leaderboard"),
  matchForm: document.querySelector("#matchForm"),
  matchList: document.querySelector("#matchList"),
  matchName: document.querySelector("#matchName"),
  matchNote: document.querySelector("#matchNote"),
  matchTeamA: document.querySelector("#matchTeamA"),
  matchTeamB: document.querySelector("#matchTeamB"),
  playerCount: document.querySelector("#playerCount"),
  playerCredit: document.querySelector("#playerCredit"),
  playerForm: document.querySelector("#playerForm"),
  playerList: document.querySelector("#playerList"),
  playerName: document.querySelector("#playerName"),
  predictionForm: document.querySelector("#predictionForm"),
  predictionLanes: document.querySelector("#predictionLanes"),
  predictionMatch: document.querySelector("#predictionMatch"),
  predictionPlayer: document.querySelector("#predictionPlayer"),
  resetDataButton: document.querySelector("#resetDataButton"),
  settleForm: document.querySelector("#settleForm"),
  settleLanes: document.querySelector("#settleLanes"),
  settleMatch: document.querySelector("#settleMatch"),
  syncCloudButton: document.querySelector("#syncCloudButton"),
  toast: document.querySelector("#toast"),
  winnerCredit: document.querySelector("#winnerCredit"),
  exactScoreCredit: document.querySelector("#exactScoreCredit"),
};

function createId(prefix) {
  return `${prefix}_${Date.now().toString(36)}_${Math.random().toString(36).slice(2, 8)}`;
}

function loadState() {
  try {
    const saved = JSON.parse(localStorage.getItem(STORAGE_KEY));
    return normalizeState(saved);
  } catch {
    return normalizeState();
  }
}

function saveState(options = {}) {
  localStorage.setItem(STORAGE_KEY, JSON.stringify(state));
  if (options.sync !== false) {
    queueCloudSave();
  }
}

function normalizeState(data = {}) {
  return {
    players: Array.isArray(data.players) ? data.players : [],
    matches: Array.isArray(data.matches) ? data.matches : [],
    predictions: Array.isArray(data.predictions) ? data.predictions : [],
    ledger: Array.isArray(data.ledger) ? data.ledger : [],
  };
}

function replaceState(nextState) {
  const normalized = normalizeState(nextState);
  state.players = normalized.players;
  state.matches = normalized.matches;
  state.predictions = normalized.predictions;
  state.ledger = normalized.ledger;
}

function getSupabaseConfig() {
  const config = window.CREDIT_APP_SUPABASE || {};
  return {
    url: String(config.url || "").trim(),
    anonKey: String(config.anonKey || "").trim(),
    table: String(config.table || "credit_app_state").trim(),
    rowId: String(config.rowId || "main").trim(),
  };
}

function initCloud() {
  if (!cloud.config.url || !cloud.config.anonKey) {
    updateCloudStatus("本地模式", "offline");
    return;
  }

  if (!window.supabase?.createClient) {
    updateCloudStatus("云端未加载", "offline");
    showToast("Supabase SDK 未加载，当前仍使用本地数据");
    return;
  }

  cloud.client = window.supabase.createClient(cloud.config.url, cloud.config.anonKey);
  cloud.ready = true;
  updateCloudStatus("连接中", "syncing");
  pullCloudState({ silent: true });
}

function updateCloudStatus(text, mode = "offline") {
  if (!dom.cloudStatus) return;
  dom.cloudStatus.textContent = text;
  dom.cloudStatus.classList.remove("online", "offline", "syncing", "error");
  dom.cloudStatus.classList.add(mode);
}

function queueCloudSave() {
  if (!cloud.ready || cloud.syncing) return;

  window.clearTimeout(cloud.saveTimer);
  cloud.saveTimer = window.setTimeout(() => {
    saveCloudState();
  }, 450);
}

async function saveCloudState() {
  if (!cloud.ready) return;

  try {
    cloud.syncing = true;
    updateCloudStatus("同步中", "syncing");
    const { error } = await cloud.client.from(cloud.config.table).upsert(
      {
        id: cloud.config.rowId,
        data: normalizeState(state),
        updated_at: new Date().toISOString(),
      },
      { onConflict: "id" },
    );

    if (error) throw error;
    updateCloudStatus("已同步", "online");
  } catch (error) {
    updateCloudStatus("同步失败", "error");
    showToast(`云同步失败：${error.message || "请检查配置"}`);
  } finally {
    cloud.syncing = false;
  }
}

async function pullCloudState(options = {}) {
  if (!cloud.ready) {
    showToast("还没有配置云数据库");
    return;
  }

  try {
    cloud.syncing = true;
    updateCloudStatus("同步中", "syncing");
    const { data, error } = await cloud.client
      .from(cloud.config.table)
      .select("data")
      .eq("id", cloud.config.rowId)
      .maybeSingle();

    if (error) throw error;

    if (data?.data) {
      replaceState(data.data);
      saveState({ sync: false });
      renderAll();
      updateCloudStatus("已同步", "online");
      if (!options.silent) showToast("已从云端同步");
      return;
    }

    await saveCloudState();
    if (!options.silent) showToast("云端已初始化");
  } catch (error) {
    updateCloudStatus("同步失败", "error");
    showToast(`云同步失败：${error.message || "请检查配置"}`);
  } finally {
    cloud.syncing = false;
  }
}

function showToast(message) {
  dom.toast.textContent = message;
  dom.toast.classList.add("show");
  window.clearTimeout(showToast.timer);
  showToast.timer = window.setTimeout(() => {
    dom.toast.classList.remove("show");
  }, 2200);
}

function getPlayer(playerId) {
  return state.players.find((player) => player.id === playerId);
}

function getMatch(matchId) {
  return state.matches.find((match) => match.id === matchId);
}

function isCombinedMatch(match) {
  return match?.ruleType === "winner_score" || !Array.isArray(match?.lanes);
}

function getMatchRules(match) {
  return {
    winnerCredit: Number(match?.winnerCredit ?? match?.rules?.winnerCredit ?? 2),
    exactScoreCredit: Number(match?.exactScoreCredit ?? match?.rules?.exactScoreCredit ?? 5),
  };
}

function getTeamLabel(match, winner) {
  if (winner === "A") return match.teamA || "A";
  if (winner === "B") return match.teamB || "B";
  return "未填写";
}

function formatCombinedPrediction(match, value) {
  if (!value || typeof value !== "object") return "未填写";
  const winner = getTeamLabel(match, value.winner);
  return `${winner} · ${value.score || "未填比分"}`;
}

function renderCombinedRecord(match, prediction, player) {
  const value = prediction?.value && typeof prediction.value === "object" ? prediction.value : {};

  if (match.status !== "open") {
    return `
      <div class="prediction-summary">
        <span class="summary-chip">${escapeHtml(player?.name || "未知玩家")}</span>
        <span class="summary-chip">${escapeHtml(formatCombinedPrediction(match, value))}</span>
      </div>
    `;
  }

  return `
    <form class="record-edit-form" data-prediction-id="${prediction.id}">
      <span class="record-player-name">${escapeHtml(player?.name || "未知玩家")}</span>
      <label>
        胜负
        <select class="record-winner" required>
          <option value="A"${value.winner === "A" ? " selected" : ""}>${escapeHtml(match.teamA || "A")}</option>
          <option value="B"${value.winner === "B" ? " selected" : ""}>${escapeHtml(match.teamB || "B")}</option>
        </select>
      </label>
      <label>
        比分
        <input class="record-score" type="text" placeholder="例如：2-1" value="${escapeAttribute(value.score || "")}" required />
      </label>
      <button class="mini-button" type="submit">保存</button>
    </form>
  `;
}

function formatPredictionValue(lane, value) {
  if (!value) return "未填写";
  if (lane.type === "winner") {
    return value === "A" ? lane.teamA : lane.teamB;
  }
  return value;
}

function renderLeaderboard() {
  const sorted = [...state.players].sort((a, b) => b.credits - a.credits || a.name.localeCompare(b.name, "zh-CN"));
  dom.playerCount.textContent = `${state.players.length} 人`;

  if (!sorted.length) {
    dom.leaderboard.innerHTML = `<li class="empty">还没有玩家</li>`;
    return;
  }

  dom.leaderboard.innerHTML = sorted
    .map(
      (player, index) => `
        <li class="rank-row">
          <span class="rank-number">${index + 1}</span>
          <span class="name">${escapeHtml(player.name)}</span>
          <form class="credit-adjust-form" data-player-id="${player.id}">
            <input class="credit-adjust-input" type="number" inputmode="numeric" value="${player.credits}" aria-label="调整 ${escapeAttribute(player.name)} 的 credit" />
            <button class="mini-button" type="submit">更新</button>
          </form>
        </li>
      `,
    )
    .join("");
}

function renderPlayers() {
  if (!state.players.length) {
    dom.playerList.innerHTML = `<div class="empty">先添加几个玩家</div>`;
    return;
  }

  dom.playerList.innerHTML = state.players
    .map(
      (player) => `
        <form class="player-edit-form" data-player-id="${player.id}">
          <label>
            昵称
            <input class="player-edit-name" type="text" value="${escapeAttribute(player.name)}" autocomplete="off" required />
          </label>
          <span class="credit">${player.credits}</span>
          <button class="mini-button" type="submit">保存</button>
        </form>
      `,
    )
    .join("");
}

function renderSelects() {
  const playerOptions = state.players
    .map((player) => `<option value="${player.id}">${escapeHtml(player.name)}</option>`)
    .join("");
  const openMatches = state.matches.filter((match) => match.status === "open");
  const allMatchOptions = state.matches
    .map((match) => `<option value="${match.id}">${escapeHtml(match.name)}${match.status === "settled" ? "（已结算）" : ""}</option>`)
    .join("");
  const openMatchOptions = openMatches
    .map((match) => `<option value="${match.id}">${escapeHtml(match.name)}</option>`)
    .join("");

  dom.predictionPlayer.innerHTML = playerOptions || `<option value="">先添加玩家</option>`;
  dom.predictionMatch.innerHTML = openMatchOptions || `<option value="">暂无可竞猜比赛</option>`;
  dom.settleMatch.innerHTML = allMatchOptions || `<option value="">先创建比赛</option>`;
}

function renderPredictionLanes() {
  const match = getMatch(dom.predictionMatch.value);

  if (!match || match.status !== "open") {
    dom.predictionLanes.innerHTML = `<div class="empty">选择未结算的比赛后填写竞猜</div>`;
    return;
  }

  if (isCombinedMatch(match)) {
    const existing = state.predictions.find(
      (prediction) =>
        prediction.playerId === dom.predictionPlayer.value &&
        prediction.matchId === match.id &&
        prediction.laneId === COMBINED_LANE_ID,
    );
    const value = existing?.value && typeof existing.value === "object" ? existing.value : {};
    const rules = getMatchRules(match);

    dom.predictionLanes.innerHTML = `
      <div class="prediction-card combined-card" data-lane-id="${COMBINED_LANE_ID}">
        <div class="form-grid">
          <label>
            胜负
            <select class="prediction-winner" required>
              <option value="A"${value.winner === "A" ? " selected" : ""}>${escapeHtml(match.teamA || "A")}</option>
              <option value="B"${value.winner === "B" ? " selected" : ""}>${escapeHtml(match.teamB || "B")}</option>
            </select>
          </label>
          <label>
            比分
            <input class="prediction-score" type="text" placeholder="例如：2-1" value="${escapeAttribute(value.score || "")}" required />
          </label>
        </div>
        <p class="muted">胜负猜对 +${rules.winnerCredit}；胜负和比分都猜对一共 +${rules.exactScoreCredit}</p>
      </div>
    `;
    return;
  }

  dom.predictionLanes.innerHTML = match.lanes
    .map((lane) => {
      const existing = state.predictions.find(
        (prediction) =>
          prediction.playerId === dom.predictionPlayer.value &&
          prediction.matchId === match.id &&
          prediction.laneId === lane.id,
      );

      if (lane.type === "winner") {
        return `
          <div class="prediction-card" data-lane-id="${lane.id}">
            <label>
              ${escapeHtml(lane.title)}
              <select class="prediction-value">
                <option value="A"${existing?.value === "A" ? " selected" : ""}>${escapeHtml(lane.teamA)}</option>
                <option value="B"${existing?.value === "B" ? " selected" : ""}>${escapeHtml(lane.teamB)}</option>
              </select>
            </label>
            <p class="muted">猜中 +${lane.winCredit}，猜错 -${lane.loseCredit}</p>
          </div>
        `;
      }

      return `
        <div class="prediction-card" data-lane-id="${lane.id}">
          <label>
            ${escapeHtml(lane.title)}
            <input class="prediction-value" type="text" placeholder="例如：2-1" value="${escapeAttribute(existing?.value || "")}" required />
          </label>
          <p class="muted">猜中 +${lane.winCredit}，猜错 -${lane.loseCredit}</p>
        </div>
      `;
    })
    .join("");
}

function renderSettleLanes() {
  const match = getMatch(dom.settleMatch.value);

  if (!match) {
    dom.settleLanes.innerHTML = `<div class="empty">选择比赛后录入结果</div>`;
    return;
  }

  if (match.status === "settled") {
    dom.settleLanes.innerHTML = `<div class="empty">这场已经结算</div>`;
    return;
  }

  if (isCombinedMatch(match)) {
    dom.settleLanes.innerHTML = `
      <div class="prediction-card combined-card" data-lane-id="${COMBINED_LANE_ID}">
        <div class="form-grid">
          <label>
            最终胜负
            <select class="settle-winner" required>
              <option value="A">${escapeHtml(match.teamA || "A")}</option>
              <option value="B">${escapeHtml(match.teamB || "B")}</option>
            </select>
          </label>
          <label>
            最终比分
            <input class="settle-score" type="text" placeholder="例如：2-1" required />
          </label>
        </div>
      </div>
    `;
    return;
  }

  dom.settleLanes.innerHTML = match.lanes
    .map((lane) => {
      if (lane.type === "winner") {
        return `
          <div class="prediction-card" data-lane-id="${lane.id}">
            <label>
              ${escapeHtml(lane.title)}
              <select class="settle-value">
                <option value="A">${escapeHtml(lane.teamA)}</option>
                <option value="B">${escapeHtml(lane.teamB)}</option>
              </select>
            </label>
          </div>
        `;
      }

      return `
        <div class="prediction-card" data-lane-id="${lane.id}">
          <label>
            ${escapeHtml(lane.title)}
            <input class="settle-value" type="text" placeholder="例如：2-1" required />
          </label>
        </div>
      `;
    })
    .join("");
}

function renderMatches() {
  if (!state.matches.length) {
    dom.matchList.innerHTML = `<div class="empty">还没有比赛</div>`;
    return;
  }

  dom.matchList.innerHTML = state.matches
    .map((match) => {
      const matchPredictions = state.predictions.filter((prediction) => prediction.matchId === match.id);
      const groupedPlayers = new Set(matchPredictions.map((prediction) => prediction.playerId));
      if (isCombinedMatch(match)) {
        const rules = getMatchRules(match);
        const predictionRows = [...groupedPlayers]
          .map((playerId) => {
            const player = getPlayer(playerId);
            const prediction = matchPredictions.find((item) => item.playerId === playerId && item.laneId === COMBINED_LANE_ID);
            return prediction ? renderCombinedRecord(match, prediction, player) : "";
          })
          .join("");

        return `
          <article class="match-card">
            <div class="match-head">
              <div>
                <h3>${escapeHtml(match.name)}</h3>
                <p class="muted">${escapeHtml(match.note || "无备注")} · ${groupedPlayers.size} 人已提交</p>
              </div>
              <span class="status ${match.status === "settled" ? "settled" : ""}">
                ${match.status === "settled" ? "已结算" : "开放中"}
              </span>
            </div>
            <div class="lane-summary">
              <span class="summary-chip">${escapeHtml(match.teamA || "A")} vs ${escapeHtml(match.teamB || "B")}</span>
              <span class="summary-chip">胜负 +${rules.winnerCredit}</span>
              <span class="summary-chip">比分全中 +${rules.exactScoreCredit}</span>
            </div>
            ${predictionRows || `<div class="empty">暂无竞猜</div>`}
          </article>
        `;
      }

      const laneChips = match.lanes
        .map(
          (lane) =>
            `<span class="summary-chip">${escapeHtml(lane.title)}：+${lane.winCredit} / -${lane.loseCredit}</span>`,
        )
        .join("");
      const predictionRows = [...groupedPlayers]
        .map((playerId) => {
          const player = getPlayer(playerId);
          const rows = match.lanes
            .map((lane) => {
              const prediction = matchPredictions.find((item) => item.playerId === playerId && item.laneId === lane.id);
              return `<span class="summary-chip">${escapeHtml(lane.title)}：${escapeHtml(formatPredictionValue(lane, prediction?.value))}</span>`;
            })
            .join("");
          return `
            <div class="prediction-summary">
              <span class="summary-chip">${escapeHtml(player?.name || "未知玩家")}</span>
              ${rows}
            </div>
          `;
        })
        .join("");

      return `
        <article class="match-card">
          <div class="match-head">
            <div>
              <h3>${escapeHtml(match.name)}</h3>
              <p class="muted">${escapeHtml(match.note || "无备注")} · ${groupedPlayers.size} 人已提交</p>
            </div>
            <span class="status ${match.status === "settled" ? "settled" : ""}">
              ${match.status === "settled" ? "已结算" : "开放中"}
            </span>
          </div>
          <div class="lane-summary">${laneChips}</div>
          ${predictionRows || `<div class="empty">暂无竞猜</div>`}
        </article>
      `;
    })
    .join("");
}

function renderAll() {
  renderLeaderboard();
  renderPlayers();
  renderSelects();
  renderPredictionLanes();
  renderSettleLanes();
  renderMatches();
}

function settleMatch(match, results) {
  const matchPredictions = state.predictions.filter((prediction) => prediction.matchId === match.id);

  if (isCombinedMatch(match)) {
    const rules = getMatchRules(match);

    matchPredictions
      .filter((prediction) => prediction.laneId === COMBINED_LANE_ID)
      .forEach((prediction) => {
        const player = getPlayer(prediction.playerId);
        const value = prediction.value && typeof prediction.value === "object" ? prediction.value : {};
        if (!player) return;

        const winnerCorrect = value.winner === results.winner;
        const scoreCorrect = normalizeValue(value.score) === normalizeValue(results.score);
        const delta = winnerCorrect && scoreCorrect ? rules.exactScoreCredit : winnerCorrect ? rules.winnerCredit : 0;

        player.credits += delta;
        prediction.result = delta === rules.exactScoreCredit ? "exact" : winnerCorrect ? "winner" : "lose";
        prediction.delta = delta;

        state.ledger.push({
          id: createId("ledger"),
          matchId: match.id,
          laneId: COMBINED_LANE_ID,
          playerId: player.id,
          delta,
          type: "match_settlement",
          createdAt: new Date().toISOString(),
        });
      });

    match.status = "settled";
    match.results = results;
    return;
  }

  matchPredictions.forEach((prediction) => {
    const lane = match.lanes.find((item) => item.id === prediction.laneId);
    const player = getPlayer(prediction.playerId);
    if (!lane || !player) return;

    const correct = normalizeValue(prediction.value) === normalizeValue(results[lane.id]);
    const delta = correct ? lane.winCredit : -lane.loseCredit;
    player.credits += delta;
    prediction.result = correct ? "win" : "lose";
    prediction.delta = delta;

    state.ledger.push({
      id: createId("ledger"),
      matchId: match.id,
      laneId: lane.id,
      playerId: player.id,
      delta,
      createdAt: new Date().toISOString(),
    });
  });

  match.status = "settled";
  match.results = results;
}

function adjustPlayerCredit(playerId, nextCredits) {
  const player = getPlayer(playerId);
  if (!player || !Number.isFinite(nextCredits)) return false;

  const previousCredits = Number(player.credits || 0);
  const delta = nextCredits - previousCredits;
  if (delta === 0) return true;

  player.credits = nextCredits;
  state.ledger.push({
    id: createId("ledger"),
    playerId: player.id,
    delta,
    type: "manual_adjustment",
    note: "排行榜手动调整",
    createdAt: new Date().toISOString(),
  });

  return true;
}

function updatePlayerName(playerId, nextName) {
  const player = getPlayer(playerId);
  const cleanName = nextName.trim();
  if (!player || !cleanName) return { ok: false, message: "昵称不能为空" };
  if (player.name === cleanName) return { ok: true };

  const previousName = player.name;
  player.name = cleanName;
  state.ledger.push({
    id: createId("ledger"),
    playerId: player.id,
    type: "player_rename",
    previousName,
    nextName: cleanName,
    createdAt: new Date().toISOString(),
  });

  return { ok: true };
}

function updateOpenPrediction(predictionId, value) {
  const prediction = state.predictions.find((item) => item.id === predictionId);
  if (!prediction) return { ok: false, message: "没有找到这条竞猜" };

  const match = getMatch(prediction.matchId);
  if (!match || match.status !== "open") {
    return { ok: false, message: "已结算的竞猜不能修改" };
  }

  prediction.value = value;
  prediction.updatedAt = new Date().toISOString();
  return { ok: true };
}

function normalizeValue(value) {
  return String(value || "")
    .trim()
    .replace(/\s+/g, "")
    .replaceAll("：", "-")
    .replaceAll(":", "-")
    .replaceAll("比", "-");
}

function escapeHtml(value) {
  return String(value ?? "")
    .replaceAll("&", "&amp;")
    .replaceAll("<", "&lt;")
    .replaceAll(">", "&gt;")
    .replaceAll('"', "&quot;")
    .replaceAll("'", "&#039;");
}

function escapeAttribute(value) {
  return escapeHtml(value).replaceAll("`", "&#096;");
}

dom.playerForm.addEventListener("submit", (event) => {
  event.preventDefault();
  const name = dom.playerName.value.trim();
  if (!name) return;

  state.players.push({
    id: createId("player"),
    name,
    credits: Number(dom.playerCredit.value || 0),
  });

  dom.playerName.value = "";
  saveState();
  renderAll();
  showToast("玩家已添加");
});

dom.matchForm.addEventListener("submit", (event) => {
  event.preventDefault();

  state.matches.push({
    id: createId("match"),
    name: dom.matchName.value.trim(),
    note: dom.matchNote.value.trim(),
    teamA: dom.matchTeamA.value.trim() || "A",
    teamB: dom.matchTeamB.value.trim() || "B",
    ruleType: "winner_score",
    winnerCredit: Number(dom.winnerCredit.value || 2),
    exactScoreCredit: Number(dom.exactScoreCredit.value || 5),
    status: "open",
    results: {},
    createdAt: new Date().toISOString(),
  });

  dom.matchForm.reset();
  dom.winnerCredit.value = 2;
  dom.exactScoreCredit.value = 5;
  saveState();
  renderAll();
  showToast("比赛已创建");
});

dom.predictionForm.addEventListener("submit", (event) => {
  event.preventDefault();

  const playerId = dom.predictionPlayer.value;
  const match = getMatch(dom.predictionMatch.value);
  if (!playerId || !match || match.status !== "open") {
    showToast("请选择玩家和开放中的比赛");
    return;
  }

  if (isCombinedMatch(match)) {
    const card = dom.predictionLanes.querySelector(`[data-lane-id="${COMBINED_LANE_ID}"]`);
    const value = {
      winner: card.querySelector(".prediction-winner").value,
      score: card.querySelector(".prediction-score").value.trim(),
    };
    const existing = state.predictions.find(
      (prediction) =>
        prediction.playerId === playerId &&
        prediction.matchId === match.id &&
        prediction.laneId === COMBINED_LANE_ID,
    );

    if (existing) {
      existing.value = value;
      existing.updatedAt = new Date().toISOString();
    } else {
      state.predictions.push({
        id: createId("prediction"),
        playerId,
        matchId: match.id,
        laneId: COMBINED_LANE_ID,
        value,
        createdAt: new Date().toISOString(),
      });
    }

    saveState();
    renderAll();
    showToast("竞猜已保存");
    return;
  }

  [...dom.predictionLanes.querySelectorAll(".prediction-card")].forEach((card) => {
    const laneId = card.dataset.laneId;
    const value = card.querySelector(".prediction-value").value.trim();
    const existing = state.predictions.find(
      (prediction) => prediction.playerId === playerId && prediction.matchId === match.id && prediction.laneId === laneId,
    );

    if (existing) {
      existing.value = value;
      existing.updatedAt = new Date().toISOString();
      return;
    }

    state.predictions.push({
      id: createId("prediction"),
      playerId,
      matchId: match.id,
      laneId,
      value,
      createdAt: new Date().toISOString(),
    });
  });

  saveState();
  renderAll();
  showToast("竞猜已保存");
});

dom.settleForm.addEventListener("submit", (event) => {
  event.preventDefault();

  const match = getMatch(dom.settleMatch.value);
  if (!match || match.status === "settled") {
    showToast("请选择未结算的比赛");
    return;
  }

  const results = {};
  if (isCombinedMatch(match)) {
    results.winner = dom.settleLanes.querySelector(".settle-winner").value;
    results.score = dom.settleLanes.querySelector(".settle-score").value.trim();
  } else {
    [...dom.settleLanes.querySelectorAll(".prediction-card")].forEach((card) => {
      results[card.dataset.laneId] = card.querySelector(".settle-value").value.trim();
    });
  }

  settleMatch(match, results);
  saveState();
  renderAll();
  showToast("结算完成，排行榜已刷新");
});

dom.predictionMatch.addEventListener("change", renderPredictionLanes);
dom.predictionPlayer.addEventListener("change", renderPredictionLanes);
dom.settleMatch.addEventListener("change", renderSettleLanes);
dom.syncCloudButton.addEventListener("click", () => pullCloudState());

dom.leaderboard.addEventListener("submit", (event) => {
  const form = event.target.closest(".credit-adjust-form");
  if (!form) return;

  event.preventDefault();
  const nextCredits = Number(form.querySelector(".credit-adjust-input").value);
  const adjusted = adjustPlayerCredit(form.dataset.playerId, nextCredits);

  if (!adjusted) {
    showToast("请输入有效的 credit");
    return;
  }

  saveState();
  renderAll();
  showToast("credit 已更新");
});

dom.playerList.addEventListener("submit", (event) => {
  const form = event.target.closest(".player-edit-form");
  if (!form) return;

  event.preventDefault();
  const result = updatePlayerName(form.dataset.playerId, form.querySelector(".player-edit-name").value);

  if (!result.ok) {
    showToast(result.message);
    return;
  }

  saveState();
  renderAll();
  showToast("昵称已更新");
});

dom.matchList.addEventListener("submit", (event) => {
  const form = event.target.closest(".record-edit-form");
  if (!form) return;

  event.preventDefault();
  const result = updateOpenPrediction(form.dataset.predictionId, {
    winner: form.querySelector(".record-winner").value,
    score: form.querySelector(".record-score").value.trim(),
  });

  if (!result.ok) {
    showToast(result.message);
    return;
  }

  saveState();
  renderAll();
  showToast("竞猜记录已更新");
});

dom.exportDataButton.addEventListener("click", () => {
  const blob = new Blob([JSON.stringify(state, null, 2)], { type: "application/json" });
  const url = URL.createObjectURL(blob);
  const link = document.createElement("a");
  link.href = url;
  link.download = `credit-picks-${new Date().toISOString().slice(0, 10)}.json`;
  link.click();
  URL.revokeObjectURL(url);
});

dom.importDataInput.addEventListener("change", async (event) => {
  const file = event.target.files[0];
  if (!file) return;

  try {
    const imported = JSON.parse(await file.text());
    replaceState(imported);
    saveState();
    renderAll();
    showToast("数据已导入");
  } catch {
    showToast("导入失败，请检查 JSON 文件");
  } finally {
    event.target.value = "";
  }
});

dom.resetDataButton.addEventListener("click", () => {
  const confirmed = window.confirm("确定清空当前浏览器里的所有数据吗？");
  if (!confirmed) return;

  state.players = [];
  state.matches = [];
  state.predictions = [];
  state.ledger = [];
  saveState();
  renderAll();
  showToast("数据已清空");
});

renderAll();
initCloud();

window.addEventListener("focus", () => {
  if (cloud.ready) pullCloudState({ silent: true });
});
